﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _01_Productos.Model
{
    internal class ConductoresModel
    {
        public int ID { get; set; }
        public string Nombre { get; set; }
        public string Apellido { get; set; }
        public string Ncedula { get; set; }
        public string Tlicencia { get; set; }
        public string Licencia { get; set; }

    }
}
